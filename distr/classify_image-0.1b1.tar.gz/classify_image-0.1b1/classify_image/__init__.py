"""Project version"""

__version__ = '0.1b1'

def handler(arg):
    print('Hi: s' % arg)
